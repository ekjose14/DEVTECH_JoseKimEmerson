<?php
// Database connection
$host = "localhost";
$username = "root";
$password = ""; // Replace with your database password
$dbname = "db_test"; // Replace with your database name

$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Collect form data
$name = $_POST['name'];
$movie = $_POST['movie'];
$degree = $_POST['degree'];
$gender = $_POST['gender'];
$subjects = isset($_POST['subjects']) ? implode(", ", $_POST['subjects']) : "";

// Insert data into the database
$sql = "INSERT INTO form_data (name, movie, degree, gender, subjects) 
        VALUES ('$name', '$movie', '$degree', '$gender', '$subjects')";

if ($conn->query($sql) === TRUE) {
    echo "<h1>Hello $name</h1>";
    echo "<p>You like movie \"$movie\".</p>";
    echo "<p>You are enrolled in $degree Degree.</p>";
    echo "<p>Your gender is $gender.</p>";
    echo "<p>Your favorite subject(s) are $subjects.</p>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>