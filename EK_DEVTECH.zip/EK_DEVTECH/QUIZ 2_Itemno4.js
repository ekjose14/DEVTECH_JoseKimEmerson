//Name: Kim Emerson T. Jose, ID Number: T2023 - 0091

class Vehicle {
    constructor(name, model, weight, color){
        this.name = name;
        this.model = model;
        this.color = color;
        this.weight = weight;
    }

    displayDetails(){
        console.log(`Name: ${this.name}`);
        console.log(`Model: ${this.model}`);
        console.log(`Weight: ${this.weight}`);
        console.log(`Color: ${this.color}`);
        
    }
}

const vehicle1 = new Vehicle('Honda', 'mobilio', '300kg', 'White');

console.log('Vehicle-1 Details: ');
vehicle1.displayDetails();

const vehicle2 = new Vehicle('Toyota', 'fortuner', '400kg', 'Blue');

console.log('Vehicle-2 Details: ');
vehicle2.displayDetails();

const vehicle3 = new Vehicle('Ford', 'F-150', '500kg', 'Black');

console.log('Vehicle-3 Details: ');
vehicle3.displayDetails();