class Vehicle{
    constructor(make, model, year, owner){
        this.make = make;
        this.model = model;
        this.year = year;
        this.owner = owner;
    }
    displayDetails(){
        console.log(`Make: ${this.make}`);
        console.log(`Model: ${this.model}`);
        console.log(`Year: ${this.year}`);
        console.log(`Owner Name: ${this.owner}`);
    }
}
class Car extends Vehicle{
    constructor(make, model, year, owner, doors){
        super(make, model, year, owner);
        this.doors = doors;
    }
}

const vehicle = new Vehicle('Ford', 'F-150', 2020, 'Kim Emerson Jose');

console.log('Vehicle Details: ');
vehicle.displayDetails();

const car = new Car('Honda', 'Accord', 2023, 'Kim Emerson Jose', 4);

console.log('\nCar Details: ');
car.displayDetails();