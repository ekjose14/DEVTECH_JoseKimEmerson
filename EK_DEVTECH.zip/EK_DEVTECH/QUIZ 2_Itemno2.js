//Name: Kim Emerson T. Jose, ID Number: T2023 - 0091
var number =1;
if(number > 0){
    console.log("num2 is greater");
}else{console.log("num2 is lesser");}