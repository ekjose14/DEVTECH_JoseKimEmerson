var number = 12;
if(number %2 === 0){
    console.log("It is even number");
}else{
    console.log("It is odd number");
}