//Name: Kim Emerson T. Jose, ID Number: T2023 - 0091
var number = 9;
if(number %2 === 0){
    console.log("It is odd number");
}else{console.log("It is even");}