//Name: Kim Emerson T. Jose, ID Number: T2023 - 0091
var number = -5;
if(number > 0){
    console.log("The number is positive");
}else{console.log("The number is negative");}