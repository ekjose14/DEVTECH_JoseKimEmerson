<?php
for ($i = 2; $i <= 10; $i += 2) {
    echo "Even Number: " . $i . "<br>";
}
?>
