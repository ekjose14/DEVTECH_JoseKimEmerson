<?php
$age = 16;
if ($age >= 18) {
    echo "You are an adult.";
} else {
    echo "You are not an adult.";
}
?>
