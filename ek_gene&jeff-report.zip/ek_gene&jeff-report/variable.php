<?php
$name = "John";
echo "Hello, " . $name;
?>
