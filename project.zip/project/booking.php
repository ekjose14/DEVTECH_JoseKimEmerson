<?php

require 'includes/db_connection.php'; // Database connection
require 'includes/session_check.php'; // Check if user is logged in
require 'includes/header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $court_id = 1; // Fixed court ID for the single court
    $date = $_POST['booking_date'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];
    $bookers_name = trim($_POST['bookers_name']); // Sanitize user input
    $user_id = $_SESSION['user_id'];

    // Check for conflicting bookings
    $stmt = $conn->prepare(
        "SELECT * FROM bookings 
         WHERE court_id = ? AND booking_date = ? AND 
               ((start_time < ? AND end_time > ?) OR (start_time < ? AND end_time > ?) OR 
                (start_time >= ? AND start_time < ?) OR (end_time > ? AND end_time <= ?))"
    );
    $stmt->bind_param(
        "isssssssss",
        $court_id, $date,
        $end_time, $start_time, // Check if new booking starts within an existing booking
        $start_time, $end_time, // Check if new booking ends within an existing booking
        $start_time, $end_time, // Check if new booking completely overlaps an existing one
        $start_time, $end_time  // Check if new booking is within an existing one
    );
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $error = "The court is already booked for the selected time range.";
    } else {
        // Insert booking into database
        $stmt = $conn->prepare(
            "INSERT INTO bookings (user_id, court_id, booking_date, start_time, end_time, bookers_name) 
             VALUES (?, ?, ?, ?, ?, ?)"
        );
        $stmt->bind_param("iissss", $user_id, $court_id, $date, $start_time, $end_time, $bookers_name);
        
        try {
            $stmt->execute();
            $success = "Booking successfully created!";
        } catch (mysqli_sql_exception $e) {
            $error = "This time range is already booked. " . $e->getMessage();
        }
    }
}
?>

<div class="container">
    <h2>Book a Court</h2>

    <?php if (isset($error)): ?>
        <p style="color: red;"><?php echo $error; ?></p>
    <?php endif; ?>

    <?php if (isset($success)): ?>
        <p style="color: green;"><?php echo $success; ?></p>
    <?php endif; ?>

    <form action="booking.php" method="POST">
        <label for="bookers_name">Booker's Name:</label>
        <input type="text" id="bookers_name" name="bookers_name" required placeholder="Enter your name">

        <label for="booking_date">Booking Date:</label>
        <input type="date" id="booking_date" name="booking_date" required>

        <label for="start_time">Start Time:</label>
        <input type="time" id="start_time" name="start_time" required>

        <label for="end_time">End Time:</label>
        <input type="time" id="end_time" name="end_time" required>

        <button type="submit">Book Court</button>
    </form>
</div>

<?php
require 'includes/footer.php';
?>
