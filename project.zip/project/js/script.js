// AJAX function to check availability
function checkAvailability() {
    const courtId = document.getElementById("courtId").value;
    const bookingDate = document.getElementById("bookingDate").value;
    const timeSlot = document.getElementById("timeSlot").value;

    const xhr = new XMLHttpRequest();
    xhr.open("POST", "includes/check_availability.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            const response = JSON.parse(xhr.responseText);
            const statusMessage = document.getElementById("bookingStatus");

            if (response.available) {
                statusMessage.textContent = "The selected time slot is available!";
                statusMessage.style.color = "green";
            } else {
                statusMessage.textContent = "Sorry, this slot is already booked.";
                statusMessage.style.color = "red";
            }
        }
    };

    xhr.send(`court_id=${courtId}&date=${bookingDate}&time_slot=${timeSlot}`);
}

// Call the checkAvailability function when the form changes
document.getElementById("bookingDate").addEventListener("change", checkAvailability);
document.getElementById("timeSlot").addEventListener("change", checkAvailability);
document.getElementById("courtId").addEventListener("change", checkAvailability);
