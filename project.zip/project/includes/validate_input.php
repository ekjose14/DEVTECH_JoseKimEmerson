<?php
// Function to sanitize input data to prevent XSS attacks
function sanitizeInput($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

// Validate username
function validateUsername($username) {
    return preg_match("/^[a-zA-Z0-9_]{3,20}$/", $username);
}

// Validate email format
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}
?>
