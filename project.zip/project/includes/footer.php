<footer>
<style>
footer {
    background-color: #303e5c;
    color: white;
    text-align: center;
    padding: 15px 0;
    position: fixed;
    bottom: 0;
    width: 100%;
}
</style>
    <p>&copy; 2024 Fortunil Badminton Court. All rights reserved.</p>
</footer>
</body>
</html>
