<?php
require 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $court_id = $_POST['court_id'];
    $booking_date = $_POST['date'];
    $time_slot = $_POST['time_slot'];

    // Check if the selected slot is already booked
    $stmt = $conn->prepare("SELECT COUNT(*) FROM bookings WHERE court_id = ? AND booking_date = ? AND time_slot = ?");
    $stmt->bind_param("iss", $court_id, $booking_date, $time_slot);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();

    // Return JSON response
    echo json_encode(['available' => $count == 0]);
}
?>
