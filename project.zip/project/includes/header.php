<?php

?>
<header>
<link rel="stylesheet" href="css/style.css">
    <script src="js/script.js"></script>
    <nav>
        <ul>
  
            <?php if (isset($_SESSION['user_id'])): // Only show when user is logged in ?>
                <li><a href="dashboard.php">Home</a></li>
                <li><a href="booking.php">Book a Court</a></li>
                <li><a href="logout.php">Logout</a></li>
            <?php endif; ?>
        </ul>
    </nav>
</header>
