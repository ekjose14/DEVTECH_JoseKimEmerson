<?php

require 'includes/db_connection.php';
require 'includes/session_check.php';
require 'includes/header.php';

$court_id = 1; // Fixed court ID for the single court

// Fetch all bookings for the single court
$bookings = $conn->query("SELECT * FROM bookings WHERE court_id = $court_id ORDER BY booking_date, start_time");
?>

<div class="container">
    <h2>Court Status</h2>

    <div class="court-status">
        <p><strong>Booked Slots:</strong></p>
       

        <?php if ($bookings->num_rows > 0): ?>
            <table border="1" cellspacing="0" cellpadding="10">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>Booker's Name</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($booking = $bookings->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $booking['booking_date']; ?></td>
                            <td><?php echo $booking['start_time']; ?></td>
                            <td><?php echo $booking['end_time']; ?></td>
                            <td><?php echo $booking['bookers_name']; ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>The court is currently available for booking.</p>
        <?php endif; ?>
    </div>
</div>

<?php
require 'includes/footer.php';
?>
